Important time parameters

first element of fapar is decade 0, last is N_ELEMENTS(fapar)-1

Pheno results are accordingly, from 0 (first decade) on


max_ind [phenot_p2_stat2]
Defines the postions of autocorrelation maxima, so they represent the length of the
repating cycles (first one should always be 36, nex one is the second GS)

ngspy [phenot_p2_stat2]
number of maxima found

xoffst [phenot_p2_stat2]
{intarr(2)} time position of the first and second repeating cycle (usually 36 decades)
Time seiries data before xoffst[0] are not considered

nyearsn [phenot_p1]
Sets the maximum number of 36 decades year and the number of bands in the output. 
It is computed on the base of calendar year as last_yar-first_year+1.
It has no actual meaning, is only the max number of bands required to store the outputs.


n_full_solar_years [phenot_p2_stat2]
{scalar} Is the number of full "solar year" (=36 decades) 
in the analysed series. Additional data may be available after 
xoffst[0]+36*n_full_solar_years 
Note that the analysis is performed over n_full_solar_years + 1, so it is
attempted to fit also such remaining data

search_range	[phenot_p3_pdhft_mm]
{scalar} range befor and after breakpoints in wich to serach for the current year
minima (on smoothed fapar) and define the OW (optimization window). 
Now set to 6 and 4 for 1 and 2 GS y-1, respectively